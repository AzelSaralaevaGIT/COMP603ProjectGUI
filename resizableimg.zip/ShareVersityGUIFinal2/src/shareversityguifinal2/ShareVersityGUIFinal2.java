/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package shareversityguifinal2;

/**
 *
 * @author saral
 */
public class ShareVersityGUIFinal2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here

       
        System.out.println("I am testing youuuu (again lol)");
        System.out.println("Hello wordle");

        
        System.out.println("I am testing youuuu");
        System.out.println("I am testing github desktop");

    }
    
}
